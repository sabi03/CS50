#include <stdio.h>
#include <cs50.h>

int main(void)
{
    string x = get_string("Hello! What is your name?\n");
    printf("Nice to meet you %s.\n",x);
}
