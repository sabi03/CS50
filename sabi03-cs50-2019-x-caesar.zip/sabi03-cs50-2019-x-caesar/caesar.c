#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(int argc, string argv[])
{
    //Check for one command line argument
    if (argc != 2)
    {
        printf("Usage: ./caesar key\n");
        return 1; 
    }
    //Check for positive and only digital arguments
    else if (argc == 2)
    {
        for (int i = 1; i < argc; i++)
        {
            for (int j = 0, n = strlen(argv[i]); j < n; j++)
            {
                if (!isdigit(argv[i][j]))
                {
                    printf("Usage: ./caesar key\n");
                    return 1; 
                }
            }
        }
    }
    int key = atoi(argv[1]);
    
    //Get input from user,and print encrypted text
    string plaintext = get_string("plaintext:    ");
    printf("ciphertext:   ");
    for (int i = 0, n = strlen(plaintext); i < n; i++)
    {   
        //Wraparound syntaxes C[i] = plaintext[i] + key
        char upper = ((((plaintext[i] - 'A') + key) % 26) + 'A');
        char lower = ((((plaintext[i] - 'a') + key) % 26) + 'a');
        
        //check for upper and lowercase, and keep characters that are non alphabetical
        if (isupper(plaintext[i]))
        {
            printf("%c", upper);
        }
        else if (islower(plaintext[i]))
        {
            printf("%c", lower);
        }
        else
        {
            printf("%c", plaintext[i]); 
        }
    }
    printf("\n");
}
