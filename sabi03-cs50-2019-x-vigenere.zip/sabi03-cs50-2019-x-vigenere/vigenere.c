#include <cs50.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>

int shift(char c);
int main(int argc, string argv[])
{
    //checking if keyword is only 1 array of characters
    if (argc != 2)
    {
        printf("Usage: ./vigenere keyword\n");
        return 1;
    }
    //checking for alphabetical characters in the argument
    else if (argc == 2)
    {
        for (int i = 0; i < strlen(argv[1]); i++)
        {
            if (!isalpha(argv[1][i]))
            {
                printf("Usage: ./vigenere keyword\n");
                return 1;
            }
        }
        
        string plaintext = get_string("plaintext:     ");
        printf("ciphertext:    ");
        
        //j is the counter variable that we use for the keyword
        int j = 0;
        char k = strlen(argv[1]);
        char p = strlen(plaintext);
        
        //
        for (int i = 0, s = i % k; i < p; i++)
        {
            //key j'th character will be changed to an alphabetical value with our shift function
            char key = shift(argv[1][j]);
            //Enciphering code
            char upper = ((((plaintext[i] - 'A') + key) % 26) + 'A');
            char lower = ((((plaintext[i] - 'a') + key) % 26) + 'a');
            if isupper(plaintext[i])
            {
                printf("%c", upper);
                //Increase keyword counter j by 1 if letter is upper or lower
                //wrap around keyword
                j = (j + 1) % k;
            }
            else if (islower(plaintext[i]))
            {
                printf("%c", lower);
                //,//
                j = (j + 1) % k;
            }
            else
            {
                printf("%c", plaintext[i]);
            }
        } 
    }
    printf("\n");
}

//Shift function that will take our keyword and change it to an alphabetical value form 0-25 
int shift(char c)
{
    int s = 0;
    if (isupper(c))
    {
        s = (c - 'A') % 26;
    }
    else if (islower(c))
    {
        s = (c - 'a') % 26;
    }
    return s;
}

