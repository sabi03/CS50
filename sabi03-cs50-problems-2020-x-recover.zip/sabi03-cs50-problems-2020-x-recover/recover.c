//The program recovers Jpegs from a raw file

#include <stdio.h>
#include <stdlib.h>
#include <cs50.h>


int main(int argc, char *argv[])
{
    // Enure propare usage
    if (argc != 2)
    {
        fprintf(stderr, "Usage: Enter name of file\n");
        return 1;
    }

    char *infile = argv[1];
    
    // Open file
    FILE *in_image = fopen(infile, "r");
    if (in_image == NULL)
    {
        fprintf(stderr, "File cannot be openned %s!\n", infile);
        return 2;
    }
    
    // Initialize k, as a counter, thats keeping track of JPEG's
    int k = 0;
    
    // Initialize buffer 
    unsigned char block[512];
    
    // Make space for jpeg file name
    char image[512];
    
    // Pointer to outfile
    FILE *out_image = NULL;
    
    // Read blocks of 512 bytes, and write it into image : when first jpeg is found
    // The program exits from the loop, when the sizeof of block is less then 512 bytes 
    while (fread(block, 1, 512, in_image) == 512)
    {
        // Check for signature codes indicating the beginning of JPEG file's
        if (block[0] == 0xff && block[1] == 0xd8 &&
            block[2] == 0xff && block[3] >= 0xe0 && block[3] <= 0xef)
        {
            //Close image file if one is already been created
            if (out_image != NULL)
            {
                fclose(out_image);
            }
                
            // Create name for k'th image
            sprintf(image, "%03d.jpg", k);
                
            // Open k'th image file
            out_image = fopen(image, "w");
            if (out_image == NULL)
            {
                fprintf(stderr, "Could not create %s!", image);
                return 3;
            }
                
            // Increment number of images created
            k++;
            
        }
        // write to image file only if one exists 
        if (out_image != NULL)
        {
            // write to image file
            fwrite(block, sizeof(block), 1, out_image);
        }
    }
    fclose(out_image);
    fclose(in_image);
    return 0;
}
