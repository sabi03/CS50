//Returns change in the least possible amount of coins
#include <stdio.h>
#include <cs50.h>
#include <math.h>

float get_positive_float (string prompt);

int main (void)
{
    float change = get_positive_float ("Change: ");
    
    //This will round up the number to avoid float imprecision
    int cents = round(change * 100);
   
    //Quarters
    int quarters = cents/25;
    cents = cents%25;
    //quarters variable will hold the value of the amount of quarters fitting into cents(input)
    //cents mod coins will hold the remainder value after this
    //helpful math :  0/x is always 0, mod gives you remainder
    
    //Dimes
    int dimes = cents/10;
    cents = cents%10;
    
    //Nickels
    int nickles = cents/5;
    cents = cents%5;
    
    //Pennies
    int pennies = cents/1;
    cents = cents%1;
    
    //Now we add all the coins we have used
    int allcoins = quarters+dimes+nickles+pennies;
    
    printf ("%d\n",allcoins);
}

//We need a floating number from user hthat is positive and more then zero
float get_positive_float (string prompt)
{
    float x;
    do
    {
      x = get_float ("%s",prompt);  
    }
    while (x<=0);
    return x;
}
