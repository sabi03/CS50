#include <cs50.h>
#include <stdio.h>

int get_positive_int (string prompt);
int main(void)
{
    int x = get_positive_int("Height: ");
    //Code below, to check if input is positive and within range :
    //printf ("Here:%d\n", x);
    for (int i=1; i<=x; i++)
    //parent loop to return next line
    {
        for (int j=0; j<(x-i); j++) 
        {
            printf(" ");
        }
        //this returns the space that is 0 when input is 1 and 7 maximum when input is 8
        for (int k=1; k<=i; k++)
        {
            printf("#");
        //this returns the hashtag and increments it but gets indented by spaces with the previous loop
        }
        printf("\n");
    }
}

int get_positive_int (string prompt)
{
    int x;
    do
    {
        x = get_int("%s", prompt);
    }
    while (x<1 || x>8);
    //do until this is true : x>=1 and x<=8
    //have to use || as both condition has to be false,for the while loop to stop when x is indeed between/or it is 1 and 8
    return x;
}
