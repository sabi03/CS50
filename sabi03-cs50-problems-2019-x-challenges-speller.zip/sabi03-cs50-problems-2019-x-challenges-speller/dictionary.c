// Implements a dictionary's functionality

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "dictionary.h"


// Represents number of children for each node in a trie
// Every 26 character plus apostrophy character
#define N 27

// Represents a node in a trie
typedef struct node
{
    bool is_word;
    struct node *children[N];
}
node;

// Represents a trie
node *root;

// Initializing recursive function to free nodes
void free_node(node *trav);

// Word counter and Character counter
int k = 0;
int index = 0;

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    // Initialize trie
    root = malloc(sizeof(node));
    if (root == NULL)
    {
        return false;
    }
    root->is_word = false;
    for (int i = 0; i < N; i++)
    {
        root->children[i] = NULL;
    }

    // Open dictionary
    FILE *file = fopen(dictionary, "r");
    if (file == NULL)
    {
        unload();
        fprintf(stderr, "Cannot open dictionary.");
        return false;
    }

    // Buffer for a word
    char word[LENGTH + 1];

    // Insert words into trie
    // This while function gets a word thats not longer than 45 bytes in length
    node *trav = root;
    while (fscanf(file, "%s", word) != EOF)
    {
        for (int i = 0; i < strlen(word) + 1; i++)
        {
            int num = word[i];
            // When we reached the end of a word 
            if (word[i] == '\0')
            {
                trav->is_word = true;
                trav = root;
                k++;
                break;
            }
            // If character is an apostrophy: assign index to the 27th array
            if (word[i] == 0x27)
            {
                index = 26;
            }
            else if (num >= 'a' || num <= 'z')
            {
                index = num - 'a';
            }
            else
            {
                printf("Error");
                return 1;
            }

            // If character does not exist
            if (trav->children[index] == NULL)
            {
                node *new_node = malloc(sizeof(node));
                if (new_node == NULL)
                {
                    return 1;
                }
                new_node->is_word = false;
                trav->children[index] = new_node;
                trav = new_node;
            }
            // If character exist
            else if (trav->children[index] != NULL)
            {
                trav = trav->children[index];
            }
        }
    }

    // Close dictionary
    fclose(file);
    
    // Indicate success
    return true;
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    if (k != 0)
    {
        return k;
    }
    else
    {
        return 0;
    }
}

// Returns true if word is in dictionary else false
bool check(const char *word)
{
    node *trav = root;
    int j = 0;
    for (int i = 0, n = strlen(word); i < n + 1; i++)
    {
        
        if (word[i] == '\0')
        {
            // Checking if word exist
            if (trav->is_word == true)
            {
                return true;
            }
            else if (trav->is_word == false)
            {
                return false;
            } 
        }
        if (word[i] == 0x27)
        {
            j = 26;
        }
        else if (isupper(word[i]))
        {
            j = word[i] - 'A';
        }
        else if (islower(word[i]))
        {
            j = word[i] - 'a';
        }

        // Checking if character exist

        if (trav->children[j] == NULL)
        {
            return false;
        }
        else
        {
            trav = trav->children[j];
        }
    }
    return true;
}

// Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    node *trav = root;
    if (trav)
    {
        if (root)
        {
            free_node(root);
        }
        return true;
    }
    return false;
}

// Goes to the bottom of the trie and free's the very last node
void free_node(node *trav)
{
    for (int i = 0; i < 27; i++)
    {
        if (trav->children[i])
        {
            free_node(trav->children[i]);
        }
    }

    free(trav);
    return;
}