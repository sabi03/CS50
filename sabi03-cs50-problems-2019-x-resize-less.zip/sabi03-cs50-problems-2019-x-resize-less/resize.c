// Copies a BMP file and resizes it by a factor: n (a user given number)

#include <stdio.h>
#include <stdlib.h>
#include "bmp.h"

int main(int argc, char *argv[])
{
    // ensure proper usage
    if (argc != 4)
    {
        fprintf(stderr, "Usage: copy infile outfile\n");
        return 1;
    }

    // Convert first user given data to a number
    int n = atoi(argv[1]);

    // Ensure user enters a value between 0-100
    if (n < 0 || n > 100)
    {
        fprintf(stderr, "Usage: Enter a positive value between 0 and 101\n");
        return 1;
    }

    // remember filenames
    char *infile = argv[2];
    char *outfile = argv[3];

    // open input file
    FILE *inptr = fopen(infile, "r");
    if (inptr == NULL)
    {
        fprintf(stderr, "Could not open %s.\n", infile);
        return 2;
    }

    // open output file
    FILE *outptr = fopen(outfile, "w");
    if (outptr == NULL)
    {
        fclose(inptr);
        fprintf(stderr, "Could not create %s.\n", outfile);
        return 3;
    }

    // Declare infile's and outfile's headers to keep track of all
    BITMAPFILEHEADER in_bf;
    BITMAPINFOHEADER in_bi;
    BITMAPFILEHEADER out_bf;
    BITMAPINFOHEADER out_bi;

    // read infile's BITMAPFILEHEADER
    fread(&in_bf, sizeof(BITMAPFILEHEADER), 1, inptr);
    // read infile's BITMAPINFOHEADER
    fread(&in_bi, sizeof(BITMAPINFOHEADER), 1, inptr);


    // ensure infile is (likely) a 24-bit uncompressed BMP 4.0
    if (in_bf.bfType != 0x4d42 || in_bf.bfOffBits != 54 || in_bi.biSize != 40 ||
        in_bi.biBitCount != 24 || in_bi.biCompression != 0)
    {
        fclose(outptr);
        fclose(inptr);
        fprintf(stderr, "Unsupported file format.\n");
        return 4;
    }


    // For safety, initiate outfile's headers similar to infile's
    out_bf = in_bf;
    out_bi = in_bi;

    // change height and width by factor n
    out_bi.biWidth = in_bi.biWidth * n;
    out_bi.biHeight = in_bi.biHeight * n;

    // determine infile's padding for scanlines
    int old_padding = (4 - (in_bi.biWidth * sizeof(RGBTRIPLE)) % 4) % 4;
    // determine outfile's padding for scanlines
    int new_padding = (4 - (out_bi.biWidth * sizeof(RGBTRIPLE)) % 4) % 4;

    // change image and file size in outfile's INFOHEADER
    out_bi.biSizeImage = (out_bi.biWidth * sizeof(RGBTRIPLE) + new_padding) * abs(out_bi.biHeight);
    out_bf.bfSize = out_bi.biSizeImage + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

    // write outfile's BITMAPFILEHEADER
    fwrite(&out_bf, sizeof(BITMAPFILEHEADER), 1, outptr);
    // write outfile's BITMAPINFOHEADER
    fwrite(&out_bi, sizeof(BITMAPINFOHEADER), 1, outptr);

    // The actual resizing part, lets make the picture bigger by n
    // iterate over infile's scanlines
    for (int i = 0, biHeight = abs(in_bi.biHeight); i < biHeight; i++)
    {
        //Resize vertically by factor n
        for (int l = 0; l < n; l++)
        {
            // iterate over pixels in scanline
            for (int j = 0; j < in_bi.biWidth; j++)
            {
                // temporary storage
                RGBTRIPLE triple;
                
                // read RGB triple from infile
                fread(&triple, sizeof(RGBTRIPLE), 1, inptr);
                
                // write RGB triple to outfile
                for (int k = 0; k < n; k++)
                {
                    fwrite(&triple, sizeof(RGBTRIPLE), 1, outptr);
                }
            }
            // skip over padding in the infile, if any
            fseek(inptr, old_padding, SEEK_CUR);

            // then add it back to the outfile (to demonstrate how)
            for (int k = 0; k < new_padding; k++)
            {
                fputc(0x00, outptr);
            }

            // we need to copy the width of scanline n times
            // so we need to go back to the beginning of the scanline
            fseek(inptr, -((in_bi.biWidth * sizeof(RGBTRIPLE)) + old_padding), SEEK_CUR);
        }
        // once we copied each width of scanlines by the factor n
        // we need to move to the next scanline (move pointer to the end of the scanline)
        fseek(inptr, (in_bi.biWidth * sizeof(RGBTRIPLE)) + old_padding, SEEK_CUR);
    }

    // close infile
    fclose(inptr);

    // close outfile
    fclose(outptr);


    // success
    return 0;
}
